﻿using ManagementPortal.Data;
using ManagementPortal.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace ManagementPortal.Controllers
{
    public class EmployeeController : Controller
    {
        private EmployeeContext context { get; set; }

        public EmployeeController(EmployeeContext ctx)
        {
            context = ctx;
        }

        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            ViewBag.Departments = context.Departments.OrderBy(d => d.DepartmentName).ToList();
            return View("Edit", new Employee());
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            ViewBag.Departments = context.Departments.OrderBy(d => d.DepartmentName).ToList();
            var employee = context.Employees.Find(id);
            return View(employee);
        }

        [HttpPost]
        public IActionResult Edit(Employee employee)
        {
            if (ModelState.IsValid)
            {
                if (employee.Id == 0)
                {
                    context.Employees.Add(employee);
                }
                else
                {
                    context.Employees.Update(employee);
                }
                context.SaveChanges();
                return RedirectToAction("Index", "Employee");
            }
            else
            {
                ViewBag.Departments = context.Departments.OrderBy(d => d.DepartmentName).ToList();
                ViewBag.Action = (employee.Id == 0) ? "Add" : "Edit";
                return View(employee);
            }
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            ViewBag.Action = "Delete";
            var employee = context.Employees.Find(id);
            return View(employee);
        }

        [HttpPost]
        public IActionResult Delete(Employee employee)
        {
            ViewBag.Action = "Delete";
            context.Employees.Remove(employee);
            context.SaveChanges();
            return RedirectToAction("Index", "Employee");
        }

        public IActionResult Index()
        {
            var employees = context.Employees.Include(e => e.Department).ToList();
            return View(employees);
        }

        [HttpGet]
        public IActionResult Salary()
        {
            ViewBag.Salary = 0;

            return View();
        }

        [HttpPost]
        public IActionResult Salary(Employee model)
        {
            ViewBag.Salary = model.CalculatePay();
            return View(model);
        }
    }
}