﻿namespace ManagementPortal.Models
{
    public class Department
    {
        public string DepartmentId { get; set; }
        public string DepartmentName { get; set; }
    }
}